import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { documentsAPI } from '../utils/api'
import toast from 'react-hot-toast'
import { Upload, FileText, File, CheckCircle, XCircle, Loader } from 'lucide-react'

export default function FileUpload({ onUploadDone }) {
  const [files, setFiles] = useState([])
  const [uploading, setUploading] = useState(false)
  const [results, setResults] = useState([])

  const onDrop = useCallback((accepted) => {
    const newFiles = accepted.filter(f => !files.find(e => e.name === f.name))
    setFiles(prev => [...prev, ...newFiles])
    setResults([])
  }, [files])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'], 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'] },
    multiple: true
  })

  const removeFile = (name) => {
    setFiles(prev => prev.filter(f => f.name !== name))
  }

  const handleUpload = async () => {
    if (!files.length) return
    setUploading(true)
    setResults([])

    const formData = new FormData()
    files.forEach(f => formData.append('files', f))

    try {
      const { data } = await documentsAPI.upload(formData)
      setResults(data.results)
      const success = data.results.filter(r => r.status === 'success').length
      const fail = data.results.filter(r => r.status === 'error').length
      if (success > 0) toast.success(`${success} file${success > 1 ? 's' : ''} processed successfully`)
      if (fail > 0) toast.error(`${fail} file${fail > 1 ? 's' : ''} failed`)
      if (success > 0) {
        setTimeout(() => { setFiles([]); setResults([]); onUploadDone?.() }, 2000)
      }
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="space-y-4">
      {/* Drop zone */}
      <div {...getRootProps()}
        className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
          isDragActive
            ? 'border-aeka-cyan bg-aeka-cyan/5'
            : 'border-aeka-border hover:border-aeka-cyan/40 hover:bg-aeka-surface/50'
        }`}>
        <input {...getInputProps()} />
        <Upload size={28} className={`mx-auto mb-3 ${isDragActive ? 'text-aeka-cyan' : 'text-aeka-muted'}`} />
        <p className={`text-sm font-medium ${isDragActive ? 'text-aeka-cyan' : 'text-aeka-text'}`}>
          {isDragActive ? 'Drop files here' : 'Drag & drop files here'}
        </p>
        <p className="text-xs text-aeka-muted mt-1">or click to browse</p>
        <div className="flex gap-2 justify-center mt-3">
          <span className="text-[10px] px-2 py-0.5 rounded bg-red-500/10 border border-red-500/20 text-red-400 font-mono">PDF</span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono">DOCX</span>
        </div>
      </div>

      {/* File list */}
      {files.length > 0 && (
        <div className="space-y-2">
          {files.map(f => {
            const result = results.find(r => r.file === f.name)
            return (
              <div key={f.name} className="flex items-center gap-3 p-2.5 rounded-lg bg-aeka-surface border border-aeka-border">
                {f.name.endsWith('.pdf')
                  ? <FileText size={14} className="text-red-400 flex-shrink-0" />
                  : <File size={14} className="text-blue-400 flex-shrink-0" />
                }
                <span className="flex-1 text-xs text-aeka-text truncate">{f.name}</span>
                <span className="text-[10px] text-aeka-muted font-mono">{(f.size / 1024).toFixed(0)} KB</span>

                {result ? (
                  result.status === 'success'
                    ? <CheckCircle size={14} className="text-aeka-green flex-shrink-0" />
                    : <XCircle size={14} className="text-red-400 flex-shrink-0" />
                ) : uploading ? (
                  <Loader size={14} className="text-aeka-cyan animate-spin flex-shrink-0" />
                ) : (
                  <button onClick={() => removeFile(f.name)}
                    className="text-aeka-muted hover:text-red-400 transition-colors text-xs flex-shrink-0">✕</button>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* Results summary */}
      {results.length > 0 && (
        <div className="space-y-1.5">
          {results.map(r => (
            <div key={r.file} className={`text-xs p-2 rounded-lg ${
              r.status === 'success'
                ? 'bg-aeka-green/10 border border-aeka-green/20 text-aeka-green'
                : 'bg-red-500/10 border border-red-500/20 text-red-400'
            }`}>
              <span className="font-medium">{r.file}</span> — {r.message}
            </div>
          ))}
        </div>
      )}

      {/* Upload button */}
      <button
        onClick={handleUpload}
        disabled={!files.length || uploading}
        className="w-full py-3 rounded-xl bg-gradient-to-r from-aeka-cyan to-aeka-purple text-white text-sm font-semibold hover:opacity-90 disabled:opacity-30 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2">
        {uploading ? (
          <><Loader size={15} className="animate-spin" /> Processing…</>
        ) : (
          <><Upload size={15} /> Process {files.length} File{files.length !== 1 ? 's' : ''}</>
        )}
      </button>
    </div>
  )
}
