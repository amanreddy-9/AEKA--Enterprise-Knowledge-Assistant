import { useState, useEffect } from 'react'
import { systemAPI } from '../utils/api'
import { ChevronDown, Cpu } from 'lucide-react'

const MODELS = [
  { id: 'mistral',  name: 'Mistral 7B',  desc: 'Best quality',    size: '4.1 GB', color: '#c084fc' },
  { id: 'llama3',   name: 'Llama 3 8B',  desc: 'Best reasoning',  size: '4.7 GB', color: '#a78bfa' },
  { id: 'phi3',     name: 'Phi-3 Mini',  desc: 'Ultra fast',      size: '2.2 GB', color: '#34d399' },
  { id: 'gemma2',   name: 'Gemma 2B',    desc: 'Lightweight',     size: '1.6 GB', color: '#f472b6' },
]

export default function ModelSelector({ value, onChange }) {
  const [available, setAvailable] = useState([])
  const [open, setOpen] = useState(false)

  useEffect(() => {
    systemAPI.models().then(({ data }) => {
      setAvailable(data.models.filter(m => m.available).map(m => m.id))
    }).catch(() => {})
  }, [])

  const current = MODELS.find(m => m.id === value) || MODELS[0]

  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0.65rem 0.75rem',
          background: 'rgba(255,255,255,0.03)',
          border: '1px solid rgba(120,40,200,0.25)',
          borderRadius: '10px',
          cursor: 'pointer',
          transition: 'all 0.2s',
          color: '#e8e8f0',
        }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <Cpu size={13} style={{ color: current.color }} />
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontSize: '0.8rem', fontWeight: 600, fontFamily: 'Outfit, sans-serif', color: '#e8e8f0' }}>
              {current.name}
            </div>
            <div style={{ fontSize: '0.65rem', color: 'rgba(232,232,240,0.4)', fontFamily: 'Outfit, sans-serif' }}>
              {current.desc}
            </div>
          </div>
        </div>
        <ChevronDown size={13} style={{
          color: 'rgba(232,232,240,0.35)',
          transform: open ? 'rotate(180deg)' : 'rotate(0)',
          transition: 'transform 0.2s'
        }} />
      </button>

      {open && (
        <div style={{
          position: 'absolute',
          top: 'calc(100% + 4px)',
          left: 0, right: 0,
          background: '#0d0d1a',
          border: '1px solid rgba(120,40,200,0.35)',
          borderRadius: '10px',
          overflow: 'hidden',
          zIndex: 50,
          boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
          animation: 'fadeUp 0.15s ease',
        }}>
          {MODELS.map(m => (
            <button key={m.id}
              onClick={() => { onChange(m.id); setOpen(false) }}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                padding: '0.6rem 0.75rem',
                background: value === m.id ? 'rgba(120,40,200,0.12)' : 'transparent',
                border: 'none',
                cursor: 'pointer',
                transition: 'background 0.15s',
                textAlign: 'left',
                borderBottom: '1px solid rgba(255,255,255,0.04)',
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'rgba(120,40,200,0.08)'}
              onMouseLeave={e => e.currentTarget.style.background = value === m.id ? 'rgba(120,40,200,0.12)' : 'transparent'}
            >
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: m.color, flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.78rem', fontWeight: 500, fontFamily: 'Outfit, sans-serif', color: '#e8e8f0' }}>
                  {m.name}
                </div>
                <div style={{ fontSize: '0.62rem', color: 'rgba(232,232,240,0.35)', fontFamily: 'Outfit, sans-serif' }}>
                  {m.desc} · {m.size}
                </div>
              </div>
              <span style={{
                fontSize: '0.6rem',
                padding: '0.1rem 0.4rem',
                borderRadius: '3px',
                fontFamily: 'JetBrains Mono, monospace',
                background: available.includes(m.id) ? 'rgba(52,211,153,0.1)' : 'rgba(255,255,255,0.04)',
                border: available.includes(m.id) ? '1px solid rgba(52,211,153,0.25)' : '1px solid rgba(255,255,255,0.07)',
                color: available.includes(m.id) ? '#34d399' : 'rgba(232,232,240,0.25)',
              }}>
                {available.includes(m.id) ? 'ready' : 'pull'}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
