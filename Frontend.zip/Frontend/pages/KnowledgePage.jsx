import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { documentsAPI } from '../utils/api'
import toast from 'react-hot-toast'
import {
  ArrowLeft, Search, FileText, File, Trash2, Database,
  Layers, RefreshCw, Calendar, Hash, AlertTriangle, Sparkles
} from 'lucide-react'

export default function KnowledgePage() {
  const [documents, setDocuments] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [stats, setStats] = useState({ document_count: 0, chunk_count: 0 })
  const [deleting, setDeleting] = useState(null)
  const [showConfirmClear, setShowConfirmClear] = useState(false)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const { data } = await documentsAPI.stats()
      setDocuments(data.documents || [])
      setStats({ document_count: data.document_count, chunk_count: data.chunk_count })
    } catch {
      toast.error('Failed to load knowledge base')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (filename) => {
    setDeleting(filename)
    try {
      await documentsAPI.delete(filename)
      toast.success(`Removed: ${filename}`)
      fetchData()
    } catch {
      toast.error('Failed to delete document')
    } finally {
      setDeleting(null)
    }
  }

  const handleClearAll = async () => {
    try {
      await documentsAPI.clearAll()
      toast.success('Knowledge base cleared')
      setDocuments([])
      setStats({ document_count: 0, chunk_count: 0 })
      setShowConfirmClear(false)
    } catch {
      toast.error('Failed to clear knowledge base')
    }
  }

  const filtered = documents.filter(d =>
    d.filename.toLowerCase().includes(search.toLowerCase())
  )

  const formatDate = (iso) => {
    if (!iso) return 'Unknown'
    try {
      return new Date(iso).toLocaleDateString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
      })
    } catch { return 'Unknown' }
  }

  return (
    <div className="min-h-screen bg-aeka-bg">
      <div className="fixed inset-0 bg-gradient-mesh pointer-events-none z-0" />

      {/* Header */}
      <header className="relative z-10 glass border-b border-aeka-border px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/"
              className="flex items-center gap-2 text-aeka-muted hover:text-aeka-cyan transition-colors text-sm">
              <ArrowLeft size={16} />
              Back to Chat
            </Link>
            <span className="text-aeka-border">|</span>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-aeka-cyan to-aeka-purple flex items-center justify-center">
                <Sparkles size={13} className="text-white" />
              </div>
              <h1 className="font-display font-bold text-lg text-gradient">AEKA</h1>
            </div>
            <span className="text-aeka-border hidden sm:block">/</span>
            <span className="text-aeka-text font-medium hidden sm:block">Knowledge Repository</span>
          </div>

          <div className="flex items-center gap-2">
            <button onClick={fetchData}
              className="p-2 rounded-lg border border-aeka-border text-aeka-muted hover:text-aeka-cyan hover:border-aeka-cyan/30 transition-all">
              <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            </button>
            {documents.length > 0 && (
              <button onClick={() => setShowConfirmClear(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/30 text-red-400 hover:bg-red-500/10 text-xs transition-all">
                <Trash2 size={12} />
                Clear All
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-5xl mx-auto px-6 py-8">

        {/* Stats bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Documents', value: stats.document_count, icon: Database, color: 'cyan' },
            { label: 'Total Chunks', value: stats.chunk_count, icon: Layers, color: 'violet' },
            { label: 'PDF Files', value: documents.filter(d => d.type === 'pdf').length, icon: FileText, color: 'green' },
            { label: 'DOCX Files', value: documents.filter(d => d.type === 'docx').length, icon: File, color: 'purple' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="card p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon size={14} className={`text-aeka-${color}`} />
                <p className="text-[10px] text-aeka-muted uppercase tracking-widest font-mono">{label}</p>
              </div>
              <p className={`text-2xl font-mono font-bold text-aeka-${color}`}>{value}</p>
            </div>
          ))}
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-aeka-muted" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search documents by name…"
            className="w-full bg-aeka-card border border-aeka-border rounded-xl pl-10 pr-4 py-3 text-aeka-text text-sm outline-none focus:border-aeka-cyan/50 transition-all placeholder-aeka-muted"
          />
          {search && (
            <button onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-aeka-muted hover:text-aeka-text text-xs px-1">
              ✕
            </button>
          )}
        </div>

        {/* Document list */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="flex flex-col items-center gap-3">
              <div className="flex gap-1.5">
                <span className="thinking-dot" />
                <span className="thinking-dot" />
                <span className="thinking-dot" />
              </div>
              <p className="text-aeka-muted text-sm font-mono">Loading repository…</p>
            </div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Database size={40} className="text-aeka-border mb-4" />
            <p className="text-aeka-text font-medium mb-1">
              {search ? 'No documents match your search' : 'Knowledge base is empty'}
            </p>
            <p className="text-aeka-muted text-sm">
              {search ? 'Try a different search term' : 'Upload PDF or DOCX files from the chat page'}
            </p>
            {!search && (
              <Link to="/"
                className="mt-4 px-4 py-2 rounded-lg bg-aeka-cyan/10 border border-aeka-cyan/30 text-aeka-cyan text-sm hover:bg-aeka-cyan/20 transition-all">
                Go to Chat →
              </Link>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-xs text-aeka-muted font-mono mb-4">
              Showing {filtered.length} of {documents.length} document{documents.length !== 1 ? 's' : ''}
            </p>
            {filtered.map((doc, i) => (
              <div key={doc.filename}
                className="card p-4 hover:border-aeka-border/80 transition-all animate-slide-up group"
                style={{ animationDelay: `${i * 0.04}s` }}>
                <div className="flex items-start gap-4">
                  {/* File icon */}
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    doc.type === 'pdf'
                      ? 'bg-red-500/15 border border-red-500/25'
                      : 'bg-blue-500/15 border border-blue-500/25'
                  }`}>
                    {doc.type === 'pdf'
                      ? <FileText size={18} className="text-red-400" />
                      : <File size={18} className="text-blue-400" />
                    }
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="text-aeka-text font-medium text-sm truncate">{doc.filename}</h3>
                        <div className="flex items-center gap-3 mt-1 flex-wrap">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold uppercase ${
                            doc.type === 'pdf'
                              ? 'bg-red-500/15 text-red-400 border border-red-500/20'
                              : 'bg-blue-500/15 text-blue-400 border border-blue-500/20'
                          }`}>{doc.type}</span>
                          <span className="flex items-center gap-1 text-[11px] text-aeka-muted">
                            <Layers size={10} />
                            <span className="text-aeka-violet font-mono">{doc.chunk_count}</span> chunks
                          </span>
                          {doc.ingested_at && (
                            <span className="flex items-center gap-1 text-[11px] text-aeka-muted">
                              <Calendar size={10} />
                              {formatDate(doc.ingested_at)}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Delete */}
                      <button
                        onClick={() => handleDelete(doc.filename)}
                        disabled={deleting === doc.filename}
                        className="opacity-0 group-hover:opacity-100 p-2 rounded-lg border border-red-500/20 text-red-400/60 hover:text-red-400 hover:bg-red-500/10 hover:border-red-500/40 transition-all flex-shrink-0">
                        {deleting === doc.filename
                          ? <RefreshCw size={13} className="animate-spin" />
                          : <Trash2 size={13} />
                        }
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Confirm clear modal */}
      {showConfirmClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowConfirmClear(false)} />
          <div className="relative card p-6 max-w-sm w-full animate-slide-up z-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-red-500/15 border border-red-500/25 flex items-center justify-center">
                <AlertTriangle size={18} className="text-red-400" />
              </div>
              <div>
                <h3 className="font-medium text-aeka-text">Clear All Documents?</h3>
                <p className="text-xs text-aeka-muted">This cannot be undone.</p>
              </div>
            </div>
            <p className="text-sm text-aeka-muted mb-5">
              All <span className="text-aeka-text font-medium">{documents.length} documents</span> and{' '}
              <span className="text-aeka-text font-medium">{stats.chunk_count} chunks</span> will be permanently removed
              from the knowledge base.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setShowConfirmClear(false)}
                className="flex-1 py-2 rounded-lg border border-aeka-border text-aeka-muted hover:text-aeka-text text-sm transition-all">
                Cancel
              </button>
              <button onClick={handleClearAll}
                className="flex-1 py-2 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500/25 text-sm font-medium transition-all">
                Clear All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
