import { useState, useEffect, useRef, useCallback } from 'react'
import { Link } from 'react-router-dom'
import ReactMarkdown from 'react-markdown'
import { chatAPI, documentsAPI, systemAPI } from '../utils/api'
import { useSpeech } from '../hooks/useSpeech'
import FileUpload from '../components/FileUpload'
import ModelSelector from '../components/ModelSelector'
import toast from 'react-hot-toast'
import {
  Send, Database, Layers,
  ChevronDown, ChevronUp, Volume2, Upload,
  FileText, BookOpen, Sparkles, RotateCcw, X
} from 'lucide-react'
import aekaBot from '../assets/aeka-bot.png'
import aekaLogo from '../assets/aeka-logo.png'
import techMahindraLogo from '../assets/techmahindra-logo.png'
import aekaBotVideo from '../assets/video.webm'


export default function ChatPage() {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [model, setModel] = useState('mistral')
  const [useKnowledge, setUseKnowledge] = useState(true)
  const [stats, setStats] = useState({ document_count: 0, chunk_count: 0 })
  const [ollamaStatus, setOllamaStatus] = useState('checking')
  const [showUpload, setShowUpload] = useState(false)
  const [expandedSources, setExpandedSources] = useState({})
  const [topK, setTopK] = useState(4)

  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)
  const { speak, stop, speaking, speakingId } = useSpeech()

  useEffect(() => {
    fetchStats()
    checkHealth()
    const interval = setInterval(checkHealth, 30000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  const checkHealth = async () => {
    try {
      const { data } = await systemAPI.health()
      setOllamaStatus(data.ollama === 'online' ? 'online' : 'offline')
    } catch {
      setOllamaStatus('offline')
    }
  }

  const fetchStats = async () => {
    try {
      const { data } = await documentsAPI.stats()
      setStats({ document_count: data.document_count, chunk_count: data.chunk_count })
    } catch {}
  }

  const sendMessage = useCallback(async () => {
    const query = input.trim()
    if (!query || loading) return
    if (ollamaStatus === 'offline') { toast.error('Ollama is offline. Run: ollama serve'); return }

    const userMsg = { id: Date.now(), role: 'user', content: query }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setLoading(true)

    try {
      const { data } = await chatAPI.send({ query, model, top_k: topK, use_knowledge_base: useKnowledge })
      setMessages(prev => [...prev, {
        id: Date.now() + 1, role: 'assistant',
        content: data.answer, sources: data.sources || [], model: data.model_used
      }])
    } catch (err) {
      const errMsg = err.response?.data?.detail || 'Failed to get response.'
      setMessages(prev => [...prev, {
        id: Date.now() + 1, role: 'assistant',
        content: `❌ ${errMsg}`, sources: [], model
      }])
      toast.error(errMsg)
    } finally {
      setLoading(false)
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [input, loading, model, topK, useKnowledge, ollamaStatus])

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() }
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Outfit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

        * { box-sizing: border-box; margin: 0; padding: 0; }

        .aeka-root {
          height: 100vh;
          display: flex;
          flex-direction: column;
          background: #030305;
          font-family: 'Outfit', sans-serif;
          color: #e8e8f0;
          overflow: hidden;
          position: relative;
        }

        .aeka-root::before {
          content: '';
          position: fixed;
          inset: 0;
          background:
            radial-gradient(ellipse 70% 60% at 70% 50%, rgb(0, 0, 0) 0%, transparent 55%),
            radial-gradient(ellipse 50% 40% at 30% 70%, rgb(0, 0, 0) 0%, transparent 50%),
            radial-gradient(ellipse 40% 30% at 80% 20%, rgb(0, 0, 0) 0%, transparent 45%),
            radial-gradient(ellipse 30% 25% at 20% 30%, rgb(0, 0, 0) 0%, transparent 40%);
          pointer-events: none;
          z-index: 0;
          animation: bgShift 6s ease-in-out infinite alternate;
        }

        @keyframes bgShift {
          0%   { opacity: 0.7; transform: scale(1) rotate(0deg); }
          100% { opacity: 1;   transform: scale(1.08) rotate(1deg); }
        }

        /* ── Topbar ── */
        .topbar {
          position: relative;
          z-index: 20;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 1.5rem;
          height: 60px;
          background: rgba(3, 3, 5, 0.97);
          border-bottom: 1px solid rgba(120, 40, 200, 0.3);
          box-shadow: 0 1px 30px rgba(120, 40, 200, 0.15);
          flex-shrink: 0;
        }

        .topbar::after {
          content: '';
          position: absolute;
          bottom: 0; left: 0; right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(180,60,255,0.6), rgba(0,180,255,0.4), rgba(255,60,100,0.3), transparent);
        }

        .brand {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .brand-bot {
          width: 38px; height: 38px;
          object-fit: contain;
          filter: drop-shadow(0 0 8px rgba(220,60,60,0.5));
          animation: botFloat 3s ease-in-out infinite;
        }

        @keyframes botFloat {
          0%, 100% { transform: translateY(0px); }
          50%       { transform: translateY(-3px); }
        }

        .brand-logo {
          height: 28px;
          object-fit: contain;
          filter: brightness(1.1);
        }

        .topbar-center {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .stat-pill {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.4rem 0.9rem;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(120,40,200,0.25);
          border-radius: 20px;
          text-decoration: none;
          transition: all 0.2s;
          cursor: pointer;
        }

        .stat-pill:hover {
          background: rgba(120,40,200,0.12);
          border-color: rgba(180,60,255,0.5);
          box-shadow: 0 0 15px rgba(120,40,200,0.2);
        }

        .stat-num {
          font-family: 'JetBrains Mono', monospace;
          font-weight: 600;
          font-size: 0.8rem;
          color: #c084fc;
        }

        .stat-label {
          font-size: 0.72rem;
          color: rgba(232,232,240,0.5);
          font-weight: 400;
        }

        .stat-divider {
          width: 1px; height: 14px;
          background: rgba(120,40,200,0.3);
        }

        .repo-arrow {
          font-size: 0.65rem;
          color: rgba(192,132,252,0.6);
          margin-left: 0.2rem;
          transition: color 0.2s;
        }

        .stat-pill:hover .repo-arrow { color: #c084fc; }

        .topbar-right {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .status-chip {
          display: flex;
          align-items: center;
          gap: 0.4rem;
          padding: 0.3rem 0.75rem;
          border-radius: 20px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.68rem;
          font-weight: 500;
        }

        .status-chip.online  { background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.3); color: #34d399; }
        .status-chip.offline { background: rgba(239,68,68,0.1);  border: 1px solid rgba(239,68,68,0.3);  color: #f87171; }
        .status-chip.checking{ background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: rgba(232,232,240,0.4); }

        .status-dot {
          width: 6px; height: 6px;
          border-radius: 50%;
          background: currentColor;
          animation: pulse 2s infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50%       { opacity: 0.4; }
        }

        .upload-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.45rem 1rem;
          background: linear-gradient(135deg, rgba(180,60,255,0.2), rgba(220,60,60,0.15));
          border: 1px solid rgba(180,60,255,0.4);
          border-radius: 8px;
          color: #d8b4fe;
          font-size: 0.78rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          font-family: 'Outfit', sans-serif;
          letter-spacing: 0.3px;
        }

        .upload-btn:hover {
          background: linear-gradient(135deg, rgba(180,60,255,0.35), rgba(220,60,60,0.25));
          border-color: rgba(180,60,255,0.7);
          box-shadow: 0 0 20px rgba(180,60,255,0.25);
          transform: translateY(-1px);
        }

        .clear-btn {
          padding: 0.45rem 0.5rem;
          background: transparent;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 8px;
          color: rgba(232,232,240,0.35);
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
        }

        .clear-btn:hover {
          border-color: rgba(255,255,255,0.2);
          color: rgba(232,232,240,0.7);
        }

        .techmahindra-logo {
          height: 32px;
          object-fit: contain;
          opacity: 0.85;
          filter: brightness(1.1);
        }

        /* ── Layout ── */
        .main-layout {
          position: relative;
          z-index: 10;
          display: flex;
          flex: 1;
          overflow: hidden;
        }

        /* ── Sidebar ── */
        .sidebar {
          width: 240px;
          flex-shrink: 0;
          background: rgba(5, 5, 10, 0.85);
          border-right: 1px solid rgba(120,40,200,0.2);
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
          padding: 1rem;
          overflow-y: auto;
        }

        .sidebar-section-label {
          font-family: 'Calibri', sans-serif;
          font-size: 1rem;
          font-weight: 700;
          letter-spacing: 2px;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.6);
          margin-bottom: 0.4rem;
        }

        .sidebar-card {
          background: rgba(255,255,255,0.03);
          border: 1px solid rgba(120,40,200,0.2);
          border-radius: 10px;
          padding: 0.75rem;
          transition: border-color 0.2s;
        }

        .sidebar-card:hover { border-color: rgba(120,40,200,0.4); }

        .mode-btn {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 0.6rem;
          padding: 0.6rem 0.75rem;
          border-radius: 8px;
          border: 1px solid rgba(255,255,255,0.07);
          background: transparent;
          color: rgba(232,232,240,0.45);
          font-family: 'Outfit', sans-serif;
          font-size: 0.78rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          margin-bottom: 0.4rem;
          text-align: left;
        }

        .mode-btn:last-child { margin-bottom: 0; }

        .mode-btn.active-docs    { background: rgba(120,40,200,0.15); border-color: rgba(180,60,255,0.4); color: #c084fc; }
        .mode-btn.active-general { background: rgba(220,60,60,0.12);  border-color: rgba(220,60,60,0.35);  color: #fca5a5; }
        .mode-btn:not(.active-docs):not(.active-general):hover { border-color: rgba(255,255,255,0.15); color: rgba(232,232,240,0.7); }

        .slider-track {
          width: 100%;
          -webkit-appearance: none;
          height: 3px;
          border-radius: 2px;
          background: linear-gradient(90deg, #7c28c8, rgba(255,255,255,0.1));
          outline: none;
          margin: 0.5rem 0;
        }

        .slider-track::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 14px; height: 14px;
          border-radius: 50%;
          background: linear-gradient(135deg, #c084fc, #7c28c8);
          cursor: pointer;
          box-shadow: 0 0 8px rgba(192,132,252,0.5);
        }

        .kb-link { display: block; text-decoration: none; }

        .kb-nums {
          display: flex;
          justify-content: space-between;
          margin-top: 0.5rem;
        }

        .kb-num-val {
          font-family: 'JetBrains Mono', monospace;
          font-size: 1.5rem;
          font-weight: 700;
          line-height: 1;
        }

        .kb-num-val.purple { color: #c084fc; }
        .kb-num-val.red    { color: #f87171; }

        .kb-num-label {
          font-size: 0.65rem;
          color: rgba(232,232,240,0.35);
          margin-top: 0.2rem;
          letter-spacing: 0.5px;
        }

        .kb-footer {
          margin-top: 0.6rem;
          font-size: 0.65rem;
          color: rgba(192,132,252,0.4);
          transition: color 0.2s;
          font-family: 'Rajdhani', sans-serif;
          letter-spacing: 1px;
          text-transform: uppercase;
        }

        .kb-link:hover .kb-footer { color: #c084fc; }

        /* ── Chat area ── */
        .chat-area {
          flex: 1;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        .messages-container {
          flex: 1;
          overflow-y: auto;
          padding: 2rem 2.5rem;
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
          scrollbar-width: thin;
          scrollbar-color: rgba(120,40,200,0.3) transparent;
        }

        .messages-container::-webkit-scrollbar       { width: 4px; }
        .messages-container::-webkit-scrollbar-track { background: transparent; }
        .messages-container::-webkit-scrollbar-thumb { background: rgba(120,40,200,0.3); border-radius: 2px; }

        /* ── Welcome ── */
        .welcome {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100%;
          text-align: center;
          animation: fadeUp 0.6s ease forwards;
          padding-bottom: 2rem;
          gap: 0;
        }

        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to   { opacity: 1; transform: translateY(0); }
        }

        .welcome-bot {
          width: 200px; height: 200px;
          object-fit: contain;
          filter: drop-shadow(0 0 25px rgba(128, 128, 128, 0.6)) drop-shadow(0 0 50px rgba(180,0,255,0.3));
          animation: botFloat 3s ease-in-out infinite;
          margin-bottom: 1.25rem;
        }

        .welcome-logo {
          height: 100px;
          object-fit: contain;
          margin-bottom: 1rem;
          filter: brightness(1.1);
        }

        .welcome-tagline {
          font-size: 1rem;
          color: rgba(255,255,255,0.75);
          max-width: 480px;
          line-height: 1.7;
          font-weight: 400;
          margin-bottom: 2rem;
          letter-spacing: 0.2px;
        }

        .welcome-glowbox {
          position: relative;
          padding: 1.75rem 2.25rem;
          background: rgba(10,0,20,0.7);
          border: 1.5px solid rgba(160,60,255,0.5);
          border-radius: 20px;
          max-width: 600px;
          width: 100%;
          animation: borderGlow 3s ease-in-out infinite alternate;
        }

        @keyframes borderGlow {
          0%   { box-shadow: 0 0 15px rgba(120,40,200,0.3), 0 0 40px rgba(120,40,200,0.1); border-color: rgba(140,50,255,0.4); }
          33%  { box-shadow: 0 0 20px rgba(0,180,255,0.25), 0 0 50px rgba(0,150,255,0.1);  border-color: rgba(0,180,255,0.5); }
          66%  { box-shadow: 0 0 20px rgba(255,0,180,0.2),  0 0 45px rgba(255,0,150,0.1);  border-color: rgba(255,0,180,0.4); }
          100% { box-shadow: 0 0 15px rgba(120,40,200,0.3), 0 0 40px rgba(120,40,200,0.1); border-color: rgba(140,50,255,0.4); }
        }

        .suggestions-label {
          font-family: 'Rajdhani', sans-serif;
          font-size: 0.7rem;
          font-weight: 700;
          letter-spacing: 3px;
          text-transform: uppercase;
          color: rgba(200,150,255,0.5);
          margin-bottom: 1rem;
        }

        .suggestions-grid {
          display: flex;
          flex-wrap: wrap;
          gap: 0.75rem;
          justify-content: center;
        }

        .suggestion-chip {
          padding: 0.65rem 1.25rem;
          background: rgba(255,255,255,0.04);
          border: 1.5px solid rgba(140,60,255,0.45);
          border-radius: 10px;
          font-size: 0.82rem;
          font-weight: 600;
          color: rgba(255,255,255,0.8);
          cursor: pointer;
          transition: all 0.22s ease;
          font-family: 'Outfit', sans-serif;
          position: relative;
          z-index: 10;
          letter-spacing: 0.3px;
        }

        .suggestion-chip:hover {
          background: linear-gradient(135deg, rgba(120,40,200,0.3), rgba(0,150,255,0.2));
          border-color: rgba(180,100,255,0.9);
          color: #ffffff;
          box-shadow: 0 0 18px rgba(140,60,255,0.45), 0 0 35px rgba(0,150,255,0.15);
          transform: translateY(-2px) scale(1.02);
        }

        /* ── Messages ── */
        .msg-row {
          display: flex;
          gap: 0.85rem;
          animation: msgIn 0.35s cubic-bezier(0.16,1,0.3,1) forwards;
        }

        .msg-row.user { justify-content: flex-end; }

        @keyframes msgIn {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }

        .msg-avatar {
          width: 32px; height: 32px;
          border-radius: 8px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-top: 2px;
          overflow: hidden;
        }

        .msg-avatar.bot {
          background: linear-gradient(135deg, rgba(120,40,200,0.4), rgba(220,60,60,0.3));
          border: 1px solid rgba(180,60,255,0.3);
        }

        .msg-avatar.user-av {
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.1);
          font-size: 0.7rem;
          font-weight: 700;
          color: rgba(232,232,240,0.4);
          font-family: 'Rajdhani', sans-serif;
        }

        .msg-avatar img {
          width: 22px; height: 22px;
          object-fit: contain;
          filter: drop-shadow(0 0 4px rgba(220,60,60,0.4));
        }

        .user-bubble {
          max-width: 520px;
          background: linear-gradient(135deg, rgba(120,40,200,0.18), rgba(180,60,255,0.08));
          border: 1px solid rgba(180,60,255,0.25);
          border-radius: 14px 14px 2px 14px;
          padding: 0.75rem 1rem;
        }

        .user-bubble p {
          font-size: 0.88rem;
          line-height: 1.65;
          color: #e8e8f0;
        }

        .bot-bubble { max-width: 680px; }

        .bot-bubble-inner {
          background: rgba(255,255,255,0.03);
          border: 1px solid rgba(120,40,200,0.2);
          border-radius: 2px 14px 14px 14px;
          padding: 1rem 1.25rem;
          transition: border-color 0.2s;
        }

        .bot-bubble-inner:hover { border-color: rgba(120,40,200,0.35); }

        .prose-content {
          font-size: 0.875rem;
          line-height: 1.75;
          color: rgba(232,232,240,0.9);
        }

        .prose-content p      { margin: 0.4em 0; }
        .prose-content ul     { padding-left: 1.3em; list-style: disc; }
        .prose-content ol     { padding-left: 1.3em; }
        .prose-content li     { margin: 0.2em 0; }
        .prose-content strong { color: #c084fc; font-weight: 600; }
        .prose-content code   {
          background: rgba(192,132,252,0.1);
          border: 1px solid rgba(192,132,252,0.2);
          border-radius: 4px;
          padding: 0.1em 0.4em;
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.82em;
          color: #c084fc;
        }

        /* ── Message actions ── */
        .msg-actions {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          margin-top: 0.75rem;
          padding-top: 0.6rem;
          border-top: 1px solid rgba(255,255,255,0.05);
        }

        .model-tag {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.65rem;
          padding: 0.15rem 0.5rem;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 4px;
          color: rgba(232,232,240,0.3);
        }

        .action-btn {
          display: flex;
          align-items: center;
          gap: 0.35rem;
          padding: 0.25rem 0.65rem;
          background: transparent;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 6px;
          font-size: 0.7rem;
          color: rgba(232,232,240,0.4);
          cursor: pointer;
          transition: all 0.2s;
          font-family: 'Outfit', sans-serif;
        }

        .action-btn:hover         { border-color: rgba(192,132,252,0.35); color: #c084fc; }
        .action-btn.speaking      { background: rgba(192,132,252,0.1); border-color: rgba(192,132,252,0.4); color: #c084fc; }
        .action-btn.sources-btn   { margin-left: auto; }
        .action-btn.sources-btn:hover { border-color: rgba(248,113,113,0.35); color: #fca5a5; }

        .sound-bars {
          display: flex;
          align-items: center;
          gap: 2px;
          height: 14px;
        }

        .sbar {
          width: 2px;
          background: #c084fc;
          border-radius: 1px;
          animation: swave 0.7s ease-in-out infinite;
        }

        .sbar:nth-child(2) { animation-delay: 0.15s; }
        .sbar:nth-child(3) { animation-delay: 0.3s; }
        .sbar:nth-child(4) { animation-delay: 0.45s; }

        @keyframes swave {
          0%, 100% { height: 3px; }
          50%       { height: 13px; }
        }

        /* ── Sources ── */
        .sources-panel {
          margin-top: 0.6rem;
          display: flex;
          flex-direction: column;
          gap: 0.4rem;
          animation: fadeUp 0.2s ease;
        }

        .source-item {
          display: flex;
          align-items: flex-start;
          gap: 0.6rem;
          padding: 0.6rem 0.75rem;
          background: rgba(255,255,255,0.02);
          border: 1px solid rgba(120,40,200,0.15);
          border-radius: 8px;
        }

        .source-file  { font-size: 0.75rem; font-weight: 500; color: #d8b4fe; margin-bottom: 0.2rem; }
        .source-meta  { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.3rem; }

        .source-chunk {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.62rem;
          color: rgba(232,232,240,0.3);
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.07);
          border-radius: 3px;
          padding: 0.1rem 0.4rem;
        }

        .source-score {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.62rem;
          color: #34d399;
        }

        .source-text {
          font-size: 0.72rem;
          color: rgba(232,232,240,0.35);
          line-height: 1.5;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        /* ── Thinking ── */
        .thinking-bubble {
          background: rgba(255,255,255,0.03);
          border: 1px solid rgba(120,40,200,0.2);
          border-radius: 2px 14px 14px 14px;
          padding: 1rem 1.25rem;
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .think-dot {
          width: 7px; height: 7px;
          border-radius: 50%;
          animation: thinkBounce 1.2s ease-in-out infinite;
        }

        .think-dot:nth-child(1) { background: #c084fc; }
        .think-dot:nth-child(2) { background: #a78bfa; animation-delay: 0.2s; }
        .think-dot:nth-child(3) { background: #f472b6; animation-delay: 0.4s; }

        @keyframes thinkBounce {
          0%, 80%, 100% { transform: translateY(0);   opacity: 0.5; }
          40%            { transform: translateY(-6px); opacity: 1; }
        }

        /* ── Input area ── */
        .input-area {
          flex-shrink: 0;
          padding: 1rem 2rem 1.25rem;
          background: rgba(3,3,5,0.97);
          border-top: 1px solid rgba(120,40,200,0.2);
        }

        .input-row {
          display: flex;
          align-items: flex-end;
          gap: 0.75rem;
          max-width: 820px;
          margin: 0 auto;
        }

        .input-wrapper { flex: 1; position: relative; }

        .chat-input {
          width: 100%;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(120,40,200,0.25);
          border-radius: 12px;
          padding: 0.85rem 3rem 0.85rem 1.1rem;
          color: #e8e8f0;
          font-family: 'Outfit', sans-serif;
          font-size: 0.88rem;
          outline: none;
          resize: none;
          min-height: 50px;
          max-height: 120px;
          transition: border-color 0.2s, box-shadow 0.2s;
          line-height: 1.5;
        }

        .chat-input::placeholder { color: rgba(232,232,240,0.25); }

        .chat-input:focus {
          border-color: rgba(180,60,255,0.5);
          box-shadow: 0 0 0 3px rgba(120,40,200,0.08), 0 0 20px rgba(120,40,200,0.1);
        }

        .input-hint {
          position: absolute;
          right: 0.75rem; bottom: 0.7rem;
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.6rem;
          color: rgba(232,232,240,0.15);
          pointer-events: none;
        }

        .send-btn {
          width: 50px; height: 50px;
          border-radius: 12px;
          background: linear-gradient(135deg, #7c28c8, #5b21b6);
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          transition: all 0.2s;
          flex-shrink: 0;
          box-shadow: 0 4px 15px rgba(124,40,200,0.3);
        }

        .send-btn:hover:not(:disabled) {
          background: linear-gradient(135deg, #9333ea, #7c28c8);
          box-shadow: 0 4px 20px rgba(124,40,200,0.5);
          transform: translateY(-1px);
        }

        .send-btn:disabled { opacity: 0.3; cursor: not-allowed; box-shadow: none; }

        .input-footer {
          text-align: center;
          margin-top: 0.6rem;
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.62rem;
          color: rgba(232,232,240,0.2);
          letter-spacing: 0.5px;
        }

        .input-footer span { color: rgba(192,132,252,0.5); }

        /* ── Modal ── */
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.7);
          backdrop-filter: blur(8px);
          z-index: 100;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 1.5rem;
        }

        .modal-box {
          width: 100%;
          max-width: 480px;
          background: #0d0d1a;
          border: 1px solid rgba(120,40,200,0.35);
          border-radius: 16px;
          padding: 1.5rem;
          animation: fadeUp 0.25s ease;
          box-shadow: 0 20px 60px rgba(0,0,0,0.5), 0 0 40px rgba(120,40,200,0.15);
          position: relative;
        }

        .modal-box::before {
          content: '';
          position: absolute;
          top: 0; left: 10%; right: 10%;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(180,60,255,0.6), transparent);
        }

        .modal-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 1.25rem;
        }

        .modal-title {
          font-family: 'Rajdhani', sans-serif;
          font-size: 1.2rem;
          font-weight: 700;
          letter-spacing: 1px;
          background: linear-gradient(90deg, #c084fc, #f472b6);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .modal-close {
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: 6px;
          color: rgba(232,232,240,0.5);
          cursor: pointer;
          padding: 0.3rem;
          display: flex;
          align-items: center;
          transition: all 0.2s;
        }

        .modal-close:hover { background: rgba(255,255,255,0.1); color: rgba(232,232,240,0.9); }
      `}</style>

      <div className="aeka-root">

        {/* ── TOPBAR ── */}
        <header className="topbar">
          <div className="brand">
            <img src={aekaBot} alt="AEKA Bot" className="brand-bot" />
            <img src={aekaLogo} alt="AEKA" className="brand-logo" />
          </div>

          <div className="topbar-center">
            <Link to="/knowledge" className="stat-pill">
              <Database size={12} style={{ color: '#c084fc' }} />
              <span className="stat-num">{stats.document_count}</span>
              <span className="stat-label">docs</span>
              <div className="stat-divider" />
              <Layers size={12} style={{ color: '#a78bfa' }} />
              <span className="stat-num">{stats.chunk_count}</span>
              <span className="stat-label">chunks</span>
              <span className="repo-arrow">→ Repository</span>
            </Link>
          </div>

          <div className="topbar-right">
            <div className={`status-chip ${ollamaStatus}`}>
              <div className="status-dot" />
              {ollamaStatus === 'checking' ? '...' : ollamaStatus}
            </div>
            <button className="upload-btn" onClick={() => setShowUpload(true)}>
              <Upload size={13} />
              Upload
            </button>
            {messages.length > 0 && (
              <button className="clear-btn" onClick={() => { setMessages([]); stop() }} title="Clear chat">
                <RotateCcw size={13} />
              </button>
            )}
            <img src={techMahindraLogo} alt="Tech Mahindra" className="techmahindra-logo" />
          </div>
        </header>

        {/* ── MAIN LAYOUT ── */}
        <div className="main-layout">

          {/* ── SIDEBAR ── */}
          <aside className="sidebar">
            <div>
              <div className="sidebar-section-label">Model</div>
              <ModelSelector value={model} onChange={setModel} />
            </div>

            <div className="sidebar-card">
              <div className="sidebar-section-label">Context Chunks</div>
              <input
                type="range" min={1} max={8} value={topK}
                onChange={e => setTopK(Number(e.target.value))}
                className="slider-track"
              />
              <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.65rem', fontFamily:'JetBrains Mono', color:'rgba(232,232,240,0.3)', marginTop:'0.1rem' }}>
                <span>1</span>
                <span style={{ color:'#c084fc', fontWeight:700 }}>{topK}</span>
                <span>8</span>
              </div>
            </div>

            <div className="sidebar-card">
              <div className="sidebar-section-label">Query Mode</div>
              <button className={`mode-btn ${useKnowledge ? 'active-docs' : ''}`} onClick={() => setUseKnowledge(true)}>
                <BookOpen size={12} /> From Documents
              </button>
              <button className={`mode-btn ${!useKnowledge ? 'active-general' : ''}`} onClick={() => setUseKnowledge(false)}>
                <Sparkles size={12} /> General Knowledge
              </button>
            </div>

            <Link to="/knowledge" className="kb-link">
              <div className="sidebar-card">
                <div className="sidebar-section-label">Knowledge Base</div>
                <div className="kb-nums">
                  <div>
                    <div className="kb-num-val purple">{stats.document_count}</div>
                    <div className="kb-num-label">Documents</div>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <div className="kb-num-val red">{stats.chunk_count}</div>
                    <div className="kb-num-label">Chunks</div>
                  </div>
                </div>
                <div className="kb-footer">View Repository →</div>
              </div>
            </Link>
          </aside>

          {/* ── CHAT ── */}
          <main className="chat-area">
            <div className="messages-container">

              {/* Welcome screen — only shown when no messages */}
              {messages.length === 0 && (
                <div className="welcome">
                  <video
  src={aekaBotVideo}
  className="welcome-bot"
  autoPlay
  loop
  muted
  playsInline
/>
                  <img src={aekaLogo} alt="AEKA" className="welcome-logo" />
                  <p className="welcome-tagline">
                    Upload your documents and ask questions — AEKA retrieves the most relevant
                    information and generates precise, grounded answers.
                  </p>
                  <div className="welcome-glowbox">
                    <div className="suggestions-label">Try asking</div>
                    <div className="suggestions-grid">
                      {[
                        'Summarize the key findings',
                        'What are the main requirements?',
                        'Explain the architecture',
                        'List all technologies used'
                      ].map(s => (
                        <button key={s} className="suggestion-chip" onClick={() => setInput(s)}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Chat messages */}
              {messages.map((msg) => (
                <div key={msg.id} className={`msg-row ${msg.role === 'user' ? 'user' : ''}`}>
                  {msg.role === 'assistant' && (
                    <div className="msg-avatar bot">
                      <img src={aekaBot} alt="AEKA" />
                    </div>
                  )}

                  {msg.role === 'user' ? (
                    <div className="user-bubble">
                      <p>{msg.content}</p>
                    </div>
                  ) : (
                    <div className="bot-bubble">
                      <div className="bot-bubble-inner">
                        <div className="prose-content">
                          <ReactMarkdown>{msg.content}</ReactMarkdown>
                        </div>
                        <div className="msg-actions">
                          <span className="model-tag">{msg.model}</span>
                          <button
                            className={`action-btn ${speakingId === msg.id ? 'speaking' : ''}`}
                            onClick={() => speak(msg.content, msg.id)}>
                            {speakingId === msg.id ? (
                              <>
                                <div className="sound-bars">
                                  <div className="sbar" /><div className="sbar" />
                                  <div className="sbar" /><div className="sbar" />
                                </div>
                                <span>Stop</span>
                              </>
                            ) : (
                              <><Volume2 size={11} /><span>Read</span></>
                            )}
                          </button>
                          {msg.sources?.length > 0 && (
                            <button
                              className="action-btn sources-btn"
                              onClick={() => setExpandedSources(p => ({ ...p, [msg.id]: !p[msg.id] }))}>
                              <FileText size={11} />
                              <span>{msg.sources.length} source{msg.sources.length > 1 ? 's' : ''}</span>
                              {expandedSources[msg.id] ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
                            </button>
                          )}
                        </div>
                        {expandedSources[msg.id] && msg.sources?.length > 0 && (
                          <div className="sources-panel">
                            {msg.sources.slice(0, 3).map((s, i) => (
                              <div key={i} className="source-item">
                                <FileText size={12} style={{ color:'#d8b4fe', flexShrink:0, marginTop:2 }} />
                                <div style={{ flex:1, minWidth:0 }}>
                                  <div className="source-file">{s.file}</div>
                                  <div className="source-meta">
                                    <span className="source-chunk">chunk {s.chunk_id}</span>
                                    <span className="source-score">{(s.score * 100).toFixed(0)}% match</span>
                                  </div>
                                  <div className="source-text">{s.text}</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {msg.role === 'user' && (
                    <div className="msg-avatar user-av">U</div>
                  )}
                </div>
              ))}

              {/* Thinking indicator */}
              {loading && (
                <div className="msg-row">
                  <div className="msg-avatar bot">
                    <img src={aekaBot} alt="AEKA" />
                  </div>
                  <div className="thinking-bubble">
                    <div style={{ display:'flex', gap:'5px' }}>
                      <div className="think-dot" />
                      <div className="think-dot" />
                      <div className="think-dot" />
                    </div>
                    <span style={{ fontSize:'0.75rem', color:'rgba(232,232,240,0.3)', fontFamily:'JetBrains Mono' }}>
                      Searching knowledge base…
                    </span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* ── INPUT BAR ── */}
            <div className="input-area">
              <div className="input-row">
                <div className="input-wrapper">
                  <textarea
                    ref={inputRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder={useKnowledge ? 'Ask from TechM repository' : 'Ask anything…'}
                    rows={1}
                    className="chat-input"
                    onInput={e => {
                      e.target.style.height = 'auto'
                      e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
                    }}
                  />
                  <span className="input-hint">⏎ send</span>
                </div>
                <button
                  className="send-btn"
                  onClick={sendMessage}
                  disabled={!input.trim() || loading || ollamaStatus === 'offline'}>
                  <Send size={18} />
                </button>
              </div>
              <div className="input-footer">
                {useKnowledge
                  ? <><span>📚 Knowledge Base</span> · {model}</>
                  : <><span>✨ General Mode</span> · {model}</>
                }
              </div>
            </div>
          </main>
        </div>

        {/* ── UPLOAD MODAL ── */}
        {showUpload && (
          <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowUpload(false)}>
            <div className="modal-box">
              <div className="modal-header">
                <span className="modal-title">UPLOAD DOCUMENTS</span>
                <button className="modal-close" onClick={() => setShowUpload(false)}>
                  <X size={15} />
                </button>
              </div>
              <FileUpload onUploadDone={() => { fetchStats(); setShowUpload(false) }} />
            </div>
          </div>
        )}

      </div>
    </>
  )
}