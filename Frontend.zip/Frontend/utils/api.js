import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 120000,
})

export const chatAPI = {
  send: (data) => api.post('/chat', data),
}

export const documentsAPI = {
  upload: (formData) => api.post('/documents/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  list: () => api.get('/documents'),
  stats: () => api.get('/documents/stats'),
  delete: (filename) => api.delete(`/documents/${encodeURIComponent(filename)}`),
  clearAll: () => api.delete('/documents'),
}

export const systemAPI = {
  health: () => api.get('/health'),
  models: () => api.get('/models'),
}

export default api
