import { useState, useCallback, useRef } from 'react'

export function useSpeech() {
  const [speaking, setSpeaking] = useState(false)
  const [speakingId, setSpeakingId] = useState(null)
  const utteranceRef = useRef(null)

  const speak = useCallback((text, id) => {
    if (!window.speechSynthesis) return

    // Stop any current speech
    window.speechSynthesis.cancel()

    if (speakingId === id && speaking) {
      setSpeaking(false)
      setSpeakingId(null)
      return
    }

    // Clean markdown from text
    const clean = text
      .replace(/[*_`#>\[\]()]/g, '')
      .replace(/\n+/g, '. ')
      .replace(/\s+/g, ' ')
      .trim()

    const utterance = new SpeechSynthesisUtterance(clean)

    // Find American English female voice
    const setVoice = () => {
      const voices = window.speechSynthesis.getVoices()
      const female = voices.find(v =>
        v.lang === 'en-US' && (
          v.name.toLowerCase().includes('female') ||
          v.name.includes('Samantha') ||
          v.name.includes('Zira') ||
          v.name.includes('Jenny') ||
          v.name.includes('Aria') ||
          v.name.includes('Susan') ||
          v.name.includes('Karen')
        )
      ) || voices.find(v => v.lang === 'en-US') || voices[0]

      if (female) utterance.voice = female
    }

    if (window.speechSynthesis.getVoices().length > 0) {
      setVoice()
    } else {
      window.speechSynthesis.onvoiceschanged = setVoice
    }

    utterance.lang = 'en-US'
    utterance.rate = 1.0
    utterance.pitch = 1.05
    utterance.volume = 1.0

    utterance.onstart = () => { setSpeaking(true); setSpeakingId(id) }
    utterance.onend = () => { setSpeaking(false); setSpeakingId(null) }
    utterance.onerror = () => { setSpeaking(false); setSpeakingId(null) }

    utteranceRef.current = utterance
    window.speechSynthesis.speak(utterance)
  }, [speaking, speakingId])

  const stop = useCallback(() => {
    window.speechSynthesis.cancel()
    setSpeaking(false)
    setSpeakingId(null)
  }, [])

  return { speak, stop, speaking, speakingId }
}
