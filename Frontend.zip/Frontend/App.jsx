import { Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import ChatPage from './pages/ChatPage'
import KnowledgePage from './pages/KnowledgePage'

export default function App() {
  return (
    <>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#111827',
            color: '#e2e8f0',
            border: '1px solid #1e2d45',
            fontFamily: 'Inter, sans-serif',
            fontSize: '0.85rem',
          },
          success: { iconTheme: { primary: '#10b981', secondary: '#111827' } },
          error: { iconTheme: { primary: '#ef4444', secondary: '#111827' } },
        }}
      />
      <Routes>
        <Route path="/" element={<ChatPage />} />
        <Route path="/knowledge" element={<KnowledgePage />} />
      </Routes>
    </>
  )
}
